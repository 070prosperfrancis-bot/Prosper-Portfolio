import React, { useState, useEffect } from "react";

// ── Config ───────────────────────────────────────────────────
const SUPABASE_URL = "https://auyqqbjdehlpqqkqymoo.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF1eXFxYmpkZWhscHFxa3F5bW9vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQyMTAxNDMsImV4cCI6MjA4OTc4NjE0M30.wx8KByBnv6p9djg-l_wIPykSaXIpMSOk7h0fB2bfV-8";
const ADMIN_PASSWORD = "admin123";
const isDemo = SUPABASE_URL === "YOUR_SUPABASE_URL";

// ✅ PHOTO: Upload your photo to https://cloudinary.com (free)
// or https://imgur.com then paste the direct image URL below:
const PROSPER_PHOTO = "https://i.imgur.com/your-photo-id.jpg";
// Example of a working placeholder until you replace it:
const PHOTO_PLACEHOLDER = "https://ui-avatars.com/api/?name=Prosper&size=400&background=1a5c4a&color=f5a623&bold=true&font-size=0.4";

const ROLES = ["Web Designer", "Transformation Coach", "Educator"];

const DEMO = {
  posts: [
    { id:1, title:"The Power of Intentional Design", excerpt:"Great design doesn't happen by accident — it starts with a clear vision and purposeful choices.", category:"Design", date:"2026-03-10" },
    { id:2, title:"Coaching Young Minds to Greatness", excerpt:"Transformation begins the moment you decide your current situation is not your final destination.", category:"Coaching", date:"2026-03-01" },
    { id:3, title:"Why Every Student Needs a Mentor", excerpt:"Education alone isn't enough. The right mentor accelerates everything.", category:"Education", date:"2026-02-20" },
  ],
  courses: [
    { id:1, title:"UI/UX Design for Beginners", description:"Master the fundamentals of beautiful, user-centred interface design from the ground up.", price:"Free", level:"Beginner", lessons:10 },
    { id:2, title:"Youth Transformation Bootcamp", description:"A 6-week intensive coaching programme to unlock your potential and build unstoppable momentum.", price:"$49", level:"All Levels", lessons:18 },
    { id:3, title:"Web Development Fundamentals", description:"Go from zero to building real websites with HTML, CSS, and JavaScript.", price:"$29", level:"Beginner", lessons:24 },
  ],
  portfolios: [
    { id:1, title:"Lumino Brand Identity", description:"Complete brand system — logo, palette, typography, and usage guidelines.", tags:"Branding, Logo", link:"#" },
    { id:2, title:"EduTrack Web App", description:"A student progress dashboard built for modern schools.", tags:"UI/UX, React", link:"#" },
    { id:3, title:"CoachMe Mobile App", description:"Connecting coaches and students through a seamless mobile experience.", tags:"Mobile, Design", link:"#" },
  ],
  pdfs: [
    { id:1, title:"Design Thinking Playbook", description:"A practical 30-page guide to solving problems beautifully.", file_url:"#", size:"2.1 MB" },
  ],
};

// ── Supabase ─────────────────────────────────────────────────
const sb = {
  async query(table, opts={}) {
    const p = new URLSearchParams();
    if (opts.order) p.set("order", opts.order);
    const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${p}`, {
      headers:{ apikey:SUPABASE_ANON_KEY, Authorization:`Bearer ${SUPABASE_ANON_KEY}` }
    });
    return r.json();
  },
  async insert(table, data) {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
      method:"POST",
      headers:{ apikey:SUPABASE_ANON_KEY, Authorization:`Bearer ${SUPABASE_ANON_KEY}`, "Content-Type":"application/json", Prefer:"return=representation" },
      body:JSON.stringify(data)
    });
    return r.json();
  },
  async del(table, id) {
    await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=eq.${id}`, {
      method:"DELETE",
      headers:{ apikey:SUPABASE_ANON_KEY, Authorization:`Bearer ${SUPABASE_ANON_KEY}` }
    });
  }
};

// ── Tokens ───────────────────────────────────────────────────
const C = {
  green:      "#1a5c4a",
  greenDark:  "#0f3d31",
  greenLight: "#2a7c62",
  accent:     "#f5a623",
  accentHov:  "#e09415",
  white:      "#ffffff",
  offWhite:   "#f7f9f7",
  ink:        "#111c18",
  inkMid:     "#3d5047",
  inkLight:   "#7a9088",
  border:     "#dce8e2",
  cardShadow: "0 4px 28px rgba(26,92,74,0.10)",
  cardHover:  "0 12px 44px rgba(26,92,74,0.18)",
  starYellow: "#fbbf24",
};

const css = `
@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&family=Merriweather:wght@700;900&display=swap');
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body { background:${C.offWhite}; color:${C.ink}; font-family:'Nunito',sans-serif; overflow-x:hidden; }
::-webkit-scrollbar { width:5px; }
::-webkit-scrollbar-track { background:${C.offWhite}; }
::-webkit-scrollbar-thumb { background:${C.green}; border-radius:3px; }

@keyframes fadeUp    { from{opacity:0;transform:translateY(30px)} to{opacity:1;transform:translateY(0)} }
@keyframes fadeIn    { from{opacity:0} to{opacity:1} }
@keyframes float     { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-14px)} }
@keyframes sparkle   { 0%,100%{transform:scale(1) rotate(0deg);opacity:1} 50%{transform:scale(1.3) rotate(180deg);opacity:0.7} }
@keyframes blobMorph { 0%,100%{border-radius:60% 40% 55% 45%/50% 45% 55% 50%} 50%{border-radius:45% 55% 40% 60%/55% 50% 50% 45%} }
@keyframes navSlide  { from{opacity:0;transform:translateY(-10px)} to{opacity:1;transform:translateY(0)} }
@keyframes slideDown { from{opacity:0;transform:translateY(-16px)} to{opacity:1;transform:translateY(0)} }
@keyframes countUp   { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }

.fade-up { animation:fadeUp 0.65s cubic-bezier(.22,1,.36,1) both; }
.float   { animation:float 5s ease-in-out infinite; }
.sparkle { animation:sparkle 3s ease-in-out infinite; }

.mobile-menu-open { animation:slideDown 0.3s ease both; }

.card {
  background:${C.white};
  border-radius:20px;
  box-shadow:${C.cardShadow};
  transition:box-shadow 0.3s ease, transform 0.3s ease;
  border:1px solid ${C.border};
}
.card:hover { box-shadow:${C.cardHover}; transform:translateY(-5px); }

.green-btn {
  display:inline-flex; align-items:center; gap:8px;
  background:${C.accent}; color:${C.ink}; font-weight:800;
  padding:13px 28px; border-radius:50px; border:none;
  font-family:'Nunito',sans-serif; font-size:14px;
  cursor:pointer; transition:all 0.25s;
  box-shadow:0 4px 18px rgba(245,166,35,0.35);
}
.green-btn:hover { background:${C.accentHov}; transform:translateY(-2px); }

.outline-btn {
  display:inline-flex; align-items:center; gap:8px;
  background:rgba(255,255,255,0.12); color:${C.white}; font-weight:700;
  padding:12px 26px; border-radius:50px; border:2px solid rgba(255,255,255,0.35);
  font-family:'Nunito',sans-serif; font-size:14px;
  cursor:pointer; transition:all 0.25s;
}
.outline-btn:hover { background:rgba(255,255,255,0.22); }

.teal-btn {
  display:inline-flex; align-items:center; gap:8px;
  background:${C.green}; color:${C.white}; font-weight:800;
  padding:13px 28px; border-radius:50px; border:none;
  font-family:'Nunito',sans-serif; font-size:14px;
  cursor:pointer; transition:all 0.25s;
  box-shadow:0 4px 18px rgba(26,92,74,0.3);
}
.teal-btn:hover { background:${C.greenLight}; transform:translateY(-2px); }

.ghost-btn {
  display:inline-flex; align-items:center; gap:8px;
  background:transparent; color:${C.inkMid}; font-weight:700;
  padding:11px 22px; border-radius:50px; border:2px solid ${C.border};
  font-family:'Nunito',sans-serif; font-size:13px;
  cursor:pointer; transition:all 0.25s;
}
.ghost-btn:hover { border-color:${C.green}; color:${C.green}; }

.danger-btn {
  display:inline-flex; align-items:center;
  background:rgba(220,53,69,0.08); color:#dc3545; font-weight:700;
  padding:8px 18px; border-radius:50px; border:1.5px solid rgba(220,53,69,0.2);
  font-family:'Nunito',sans-serif; font-size:12px;
  cursor:pointer; transition:all 0.2s;
}

.section-label {
  display:inline-flex; align-items:center; gap:8px;
  font-size:13px; font-weight:700; letter-spacing:0.1em; text-transform:uppercase;
  color:${C.green}; margin-bottom:14px;
}
.section-label::before {
  content:''; display:inline-block; width:28px; height:3px;
  background:${C.accent}; border-radius:2px;
}

input, textarea, select {
  background:${C.offWhite}; border:1.5px solid ${C.border}; color:${C.ink};
  padding:12px 16px; border-radius:14px; font-family:'Nunito',sans-serif;
  font-size:14px; width:100%; outline:none; transition:border-color 0.2s; font-weight:500;
}
input:focus, textarea:focus, select:focus { border-color:${C.green}; }
input::placeholder, textarea::placeholder { color:${C.inkLight}; }
label {
  font-size:11px; color:${C.inkLight}; letter-spacing:0.1em; text-transform:uppercase;
  font-weight:700; display:block; margin-bottom:6px; margin-top:16px;
}

/* ── RESPONSIVE ── */
@media (max-width: 768px) {
  .hero-grid    { grid-template-columns: 1fr !important; text-align:center; }
  .hero-text    { order:2; }
  .hero-photo   { order:1; margin:0 auto; }
  .hero-btns    { justify-content:center !important; }
  .hero-stats   { justify-content:center !important; }
  .two-col      { grid-template-columns: 1fr !important; }
  .hide-mobile  { display:none !important; }
  .show-mobile  { display:flex !important; }
  .nav-pad      { padding:0 20px !important; }
  .section-pad  { padding:60px 20px !important; }
  .page-pad     { padding:100px 20px 60px !important; }
  .card-grid    { grid-template-columns: 1fr !important; }
  .stat-grid    { grid-template-columns: 1fr 1fr !important; }
  .footer-flex  { flex-direction:column !important; align-items:flex-start !important; gap:24px !important; }
  .footer-socials { flex-wrap:wrap !important; }
  .hero-h1      { font-size: clamp(28px,8vw,48px) !important; }
  .admin-pad    { padding:100px 20px 60px !important; }
  .admin-table-details { display:none !important; }
}
@media (max-width: 480px) {
  .hero-photo-wrap { width:260px !important; height:320px !important; }
  .float-badge-r  { right:-10px !important; top:10px !important; }
  .float-badge-l  { left:-10px !important; bottom:40px !important; }
  .float-pill     { right:-5px !important; bottom:5px !important; }
  .stats-row      { gap:20px !important; }
}
`;

// ── Helpers ───────────────────────────────────────────────────
function AnimRole() {
  const [idx, setIdx] = useState(0);
  const [show, setShow] = useState(true);
  useEffect(() => {
    const t = setInterval(() => {
      setShow(false);
      setTimeout(() => { setIdx(i => (i+1)%ROLES.length); setShow(true); }, 400);
    }, 3200);
    return () => clearInterval(t);
  }, []);
  return (
    <span style={{
      display:"inline-block",
      opacity:show?1:0, transform:show?"translateY(0)":"translateY(10px)",
      transition:"opacity 0.4s ease, transform 0.4s ease",
      color:C.accent, fontStyle:"italic",
    }}>{ROLES[idx]}</span>
  );
}

function Stars() {
  return <span style={{ color:C.starYellow, fontSize:16, letterSpacing:2 }}>★★★★★</span>;
}

// ── HAMBURGER NAV ─────────────────────────────────────────────
function Nav({ view, setView, isAdmin, onAdminClick, onLogout }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", h);
    return () => window.removeEventListener("scroll", h);
  }, []);

  // Close menu when navigating
  const navigate = (id) => { setView(id); setMenuOpen(false); };

  const links = [
    {id:"home",l:"🏠 Home"},
    {id:"posts",l:"✍️ Blog"},
    {id:"courses",l:"🎓 Courses"},
    {id:"portfolio",l:"🎨 Work"},
    {id:"resources",l:"📄 Resources"},
  ];

  const HamburgerIcon = () => (
    <div style={{ display:"flex", flexDirection:"column", gap:5, cursor:"pointer", padding:8 }} onClick={() => setMenuOpen(o => !o)}>
      <div style={{ width:24, height:2.5, background:C.white, borderRadius:2, transition:"all 0.3s", transform: menuOpen?"rotate(45deg) translate(5px,5px)":"none" }} />
      <div style={{ width:24, height:2.5, background:C.white, borderRadius:2, transition:"all 0.3s", opacity: menuOpen?0:1 }} />
      <div style={{ width:24, height:2.5, background:C.white, borderRadius:2, transition:"all 0.3s", transform: menuOpen?"rotate(-45deg) translate(5px,-5px)":"none" }} />
    </div>
  );

  return (
    <>
      <nav className="nav-pad" style={{
        position:"fixed", top:0, left:0, right:0, zIndex:300,
        background: scrolled?"rgba(15,61,49,0.97)":C.greenDark,
        backdropFilter:"blur(12px)",
        borderBottom:`1px solid rgba(255,255,255,0.08)`,
        transition:"background 0.3s", padding:"0 48px",
        animation:"navSlide 0.4s ease both",
      }}>
        <div style={{ maxWidth:1200, margin:"0 auto", display:"flex", alignItems:"center", height:68, gap:40 }}>
          {/* Logo */}
          <div onClick={() => navigate("home")} style={{ fontFamily:"'Merriweather',serif", fontSize:20, fontWeight:900, cursor:"pointer", color:C.white, letterSpacing:"-0.01em", flexShrink:0 }}>
            Prosper<span style={{ color:C.accent }}>.</span>
          </div>

          {/* Desktop links */}
          <div className="hide-mobile" style={{ display:"flex", gap:4, flex:1 }}>
            {links.map(l => (
              <button key={l.id} onClick={() => navigate(l.id)} style={{
                background:"none", border:"none",
                color: view===l.id ? C.accent : "rgba(255,255,255,0.75)",
                cursor:"pointer", fontFamily:"'Nunito',sans-serif", fontSize:14,
                fontWeight: view===l.id?800:600,
                padding:"8px 14px", borderRadius:50, transition:"color 0.2s",
              }}>{l.l.split(" ")[1]}</button>
            ))}
          </div>

          {/* Desktop auth buttons */}
          <div className="hide-mobile" style={{ display:"flex", gap:10 }}>
            {isAdmin
              ? <>
                  <button className="teal-btn" onClick={() => navigate("admin")} style={{ padding:"9px 20px", fontSize:13 }}>Dashboard</button>
                  <button className="ghost-btn" onClick={onLogout} style={{ color:"rgba(255,255,255,0.7)", borderColor:"rgba(255,255,255,0.2)", padding:"9px 20px", fontSize:13 }}>Logout</button>
                </>
              : <button className="green-btn" onClick={onAdminClick} style={{ padding:"10px 22px", fontSize:13 }}>Admin</button>
            }
          </div>

          {/* Mobile: spacer + hamburger */}
          <div style={{ flex:1 }} className="show-mobile" style={{ display:"none" }} />
          <div className="show-mobile" style={{ display:"none", alignItems:"center", gap:12, marginLeft:"auto" }}>
            <HamburgerIcon />
          </div>
        </div>
      </nav>

      {/* Mobile Dropdown Menu */}
      {menuOpen && (
        <div className="mobile-menu-open" style={{
          position:"fixed", top:68, left:0, right:0, zIndex:299,
          background:C.greenDark,
          borderBottom:`1px solid rgba(255,255,255,0.1)`,
          padding:"12px 0 20px",
          boxShadow:"0 12px 40px rgba(0,0,0,0.3)",
        }}>
          {links.map(l => (
            <button key={l.id} onClick={() => navigate(l.id)} style={{
              display:"block", width:"100%", textAlign:"left",
              padding:"14px 28px", background:"none", border:"none",
              color: view===l.id ? C.accent : "rgba(255,255,255,0.8)",
              fontFamily:"'Nunito',sans-serif", fontSize:16,
              fontWeight: view===l.id?800:600,
              cursor:"pointer", transition:"background 0.2s",
              borderLeft: view===l.id?`3px solid ${C.accent}`:"3px solid transparent",
            }}
            onMouseEnter={e => e.currentTarget.style.background="rgba(255,255,255,0.06)"}
            onMouseLeave={e => e.currentTarget.style.background="none"}
            >{l.l}</button>
          ))}
          <div style={{ padding:"12px 28px 0", borderTop:"1px solid rgba(255,255,255,0.08)", marginTop:8 }}>
            {isAdmin
              ? <div style={{ display:"flex", gap:10 }}>
                  <button className="teal-btn" onClick={() => navigate("admin")} style={{ fontSize:13, padding:"10px 20px" }}>Dashboard</button>
                  <button onClick={onLogout} style={{ background:"rgba(255,255,255,0.1)", color:C.white, border:"none", padding:"10px 20px", borderRadius:50, fontFamily:"'Nunito',sans-serif", fontSize:13, fontWeight:700, cursor:"pointer" }}>Logout</button>
                </div>
              : <button className="green-btn" onClick={() => { onAdminClick(); setMenuOpen(false); }} style={{ fontSize:13 }}>Admin Login</button>
            }
          </div>
        </div>
      )}
    </>
  );
}

// ── HERO ─────────────────────────────────────────────────────
function Hero({ setView }) {
  const [imgSrc, setImgSrc] = useState(PROSPER_PHOTO);

  return (
    <section style={{ background:`linear-gradient(135deg, ${C.greenDark} 0%, ${C.green} 60%, ${C.greenLight} 100%)`, minHeight:"100vh", position:"relative", overflow:"hidden", paddingTop:68 }}>

      <div className="sparkle" style={{ position:"absolute", top:80, right:"12%", fontSize:28, color:"rgba(245,166,35,0.6)" }}>✦</div>
      <div className="sparkle" style={{ position:"absolute", top:160, left:"8%", fontSize:18, color:"rgba(255,255,255,0.4)", animationDelay:"1.2s" }}>✦</div>
      <div className="sparkle" style={{ position:"absolute", bottom:160, right:"18%", fontSize:14, color:"rgba(245,166,35,0.4)", animationDelay:"2s" }}>✦</div>
      <div style={{ position:"absolute", top:-80, right:-80, width:400, height:400, borderRadius:"50%", border:"1px solid rgba(255,255,255,0.06)", pointerEvents:"none" }} />
      <div style={{ position:"absolute", bottom:40, left:-100, width:500, height:500, borderRadius:"50%", background:"rgba(0,0,0,0.06)", pointerEvents:"none" }} />

      <div className="hero-grid section-pad" style={{
        maxWidth:1200, margin:"0 auto", padding:"60px 48px",
        minHeight:"calc(100vh - 68px)",
        display:"grid", gridTemplateColumns:"1.1fr 0.9fr",
        gap:60, alignItems:"center",
      }}>
        {/* LEFT TEXT */}
        <div className="hero-text fade-up" style={{ position:"relative", zIndex:2 }}>
          <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:24, justifyContent:"inherit" }}>
            <Stars />
            <span style={{ color:"rgba(255,255,255,0.7)", fontSize:13, fontWeight:600 }}>5.0 Star · 1.2k+ Reviews</span>
          </div>

          <h1 className="hero-h1" style={{ fontFamily:"'Merriweather',serif", fontSize:"clamp(32px,4.5vw,64px)", fontWeight:900, color:C.white, lineHeight:1.12, marginBottom:20, letterSpacing:"-0.02em" }}>
            Because Growth<br />Is <span style={{ color:C.accent }}>Everything.</span> 🔥
          </h1>

          <p style={{ fontSize:16, color:"rgba(255,255,255,0.7)", lineHeight:1.85, marginBottom:10, fontWeight:500 }}>
            Hello, It's <strong style={{ color:C.white }}>Prosper</strong> — your favourite
          </p>
          <div style={{ fontSize:"clamp(18px,3vw,26px)", fontWeight:800, marginBottom:28, fontFamily:"'Merriweather',serif", minHeight:40 }}>
            <AnimRole />
          </div>
          <p style={{ fontSize:15, color:"rgba(255,255,255,0.65)", lineHeight:1.8, maxWidth:440, marginBottom:36, fontWeight:500 }}>
            Crafting beautiful digital experiences, transforming lives through coaching, and empowering the next generation through education.
          </p>

          <div className="hero-btns" style={{ display:"flex", gap:14, flexWrap:"wrap", marginBottom:44 }}>
            <button className="green-btn" onClick={() => setView("portfolio")}>View My Work</button>
            <button className="outline-btn" onClick={() => setView("courses")}>▶ Browse Courses</button>
          </div>

          <div className="hero-stats stats-row" style={{ display:"flex", gap:36 }}>
            {[{n:"20M+",l:"Happy Clients"},{n:"120+",l:"Projects"},{n:"80+",l:"Reviews"}].map(s => (
              <div key={s.l} style={{ animation:"countUp 0.6s ease both" }}>
                <div style={{ fontFamily:"'Merriweather',serif", fontSize:"clamp(20px,3vw,28px)", fontWeight:900, color:C.white }}>{s.n}</div>
                <div style={{ fontSize:12, color:"rgba(255,255,255,0.55)", fontWeight:600, marginTop:2 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* RIGHT PHOTO */}
        <div className="hero-photo fade-up" style={{ animationDelay:"0.15s", display:"flex", justifyContent:"center", position:"relative" }}>
          <div className="hero-photo-wrap" style={{ position:"relative", width:380, height:460 }}>

            <div style={{
              position:"absolute", inset:-20, borderRadius:"60% 40% 55% 45%/50% 45% 55% 50%",
              background:"rgba(255,255,255,0.09)",
              animation:"blobMorph 8s ease-in-out infinite",
            }} />

            <div className="float" style={{ position:"relative", zIndex:2, width:"100%", height:"100%" }}>
              <img
                src={imgSrc}
                onError={() => setImgSrc(PHOTO_PLACEHOLDER)}
                alt="Prosper"
                style={{
                  width:"100%", height:"100%",
                  objectFit:"cover", objectPosition:"center top",
                  borderRadius:"55% 45% 50% 50%/45% 50% 50% 55%",
                  filter:"drop-shadow(0 24px 64px rgba(0,0,0,0.35))",
                  display:"block",
                }}
              />
            </div>

            {/* Floating badge right */}
            <div className="float-badge-r" style={{
              position:"absolute", top:30, right:-40, background:C.white, borderRadius:18,
              padding:"12px 16px", boxShadow:"0 8px 32px rgba(26,92,74,0.2)", zIndex:3,
              display:"flex", alignItems:"center", gap:10, border:`1px solid ${C.border}`,
              animation:"fadeUp 0.8s 0.4s ease both",
            }}>
              <div style={{ width:40, height:40, borderRadius:10, background:`linear-gradient(135deg,${C.green},${C.greenLight})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>🎨</div>
              <div>
                <div style={{ fontSize:12, fontWeight:800, color:C.ink }}>Web Designer</div>
                <div style={{ fontSize:10, color:C.inkLight }}>3+ Years Exp.</div>
              </div>
            </div>

            {/* Floating badge left */}
            <div className="float-badge-l" style={{
              position:"absolute", bottom:80, left:-50, background:C.white, borderRadius:18,
              padding:"12px 16px", boxShadow:"0 8px 32px rgba(26,92,74,0.2)", zIndex:3,
              display:"flex", alignItems:"center", gap:10, border:`1px solid ${C.border}`,
              animation:"fadeUp 0.8s 0.6s ease both",
            }}>
              <div style={{ width:40, height:40, borderRadius:10, background:`linear-gradient(135deg,${C.accent},#f7c55a)`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>🌱</div>
              <div>
                <div style={{ fontSize:12, fontWeight:800, color:C.ink }}>Life Coach</div>
                <div style={{ fontSize:10, color:C.inkLight }}>100+ Students</div>
              </div>
            </div>

            <div className="float-pill" style={{
              position:"absolute", bottom:20, right:-20, background:C.accent, borderRadius:50,
              padding:"9px 16px", boxShadow:"0 6px 20px rgba(245,166,35,0.4)", zIndex:3,
              fontSize:12, fontWeight:800, color:C.ink,
              animation:"fadeUp 0.8s 0.8s ease both",
            }}>🎓 Educator</div>

          </div>
        </div>
      </div>

      <div style={{ position:"absolute", bottom:28, left:"50%", transform:"translateX(-50%)", textAlign:"center", color:"rgba(255,255,255,0.5)" }}>
        <div style={{ fontSize:11, letterSpacing:"0.15em", textTransform:"uppercase", marginBottom:6, fontWeight:600 }}>Scroll</div>
        <div style={{ fontSize:20 }}>↓</div>
      </div>
    </section>
  );
}

// ── WHY CHOOSE ME ─────────────────────────────────────────────
function WhyChoose() {
  const reasons = [
    { icon:"🛠", title:"End-to-End Design", desc:"From wireframes to live websites, I handle the entire design and development process with precision." },
    { icon:"🧭", title:"Certified Coach", desc:"Trained in transformational coaching with a proven track record of helping young people unlock their potential." },
    { icon:"📚", title:"Quality Education", desc:"My courses are crafted with real-world application in mind — practical, structured, and easy to follow." },
  ];
  return (
    <section style={{ background:C.white }}>
      <div className="section-pad" style={{ maxWidth:1200, margin:"0 auto", padding:"80px 48px" }}>
        <div style={{ textAlign:"center", marginBottom:52 }}>
          <div className="section-label" style={{ justifyContent:"center" }}>Why Choose Me</div>
          <h2 style={{ fontFamily:"'Merriweather',serif", fontSize:"clamp(24px,4vw,40px)", fontWeight:900, color:C.ink, lineHeight:1.2 }}>
            3 Reasons To Choose Prosper
          </h2>
        </div>
        <div className="card-grid" style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))", gap:24 }}>
          {reasons.map(r => (
            <div key={r.title} className="card" style={{ padding:28 }}>
              <div style={{ width:56, height:56, borderRadius:14, background:`linear-gradient(135deg,${C.green},${C.greenLight})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:24, marginBottom:18 }}>{r.icon}</div>
              <h3 style={{ fontFamily:"'Merriweather',serif", fontSize:17, fontWeight:700, marginBottom:10, color:C.ink }}>{r.title}</h3>
              <p style={{ fontSize:14, color:C.inkMid, lineHeight:1.8, fontWeight:500 }}>{r.desc}</p>
              <button style={{ marginTop:18, background:"none", border:"none", color:C.green, fontWeight:700, cursor:"pointer", fontFamily:"'Nunito',sans-serif", fontSize:14 }}>Read More →</button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── HOW IT WORKS ──────────────────────────────────────────────
function HowItWorks({ setView }) {
  const steps = [
    { n:"01", title:"Choose What You Need", desc:"Browse courses, portfolio projects, or coaching programmes and find what fits your goals." },
    { n:"02", title:"Engage & Learn Actively", desc:"Dive deep into structured content, live examples, and real-world projects." },
    { n:"03", title:"Transform & Grow", desc:"Apply what you've learned and watch yourself grow into the best version of yourself." },
  ];
  return (
    <section style={{ background:C.offWhite }}>
      <div className="section-pad two-col" style={{ maxWidth:1200, margin:"0 auto", padding:"80px 48px", display:"grid", gridTemplateColumns:"1fr 1fr", gap:72, alignItems:"center" }}>
        <div>
          <div className="section-label">How It Works</div>
          <h2 style={{ fontFamily:"'Merriweather',serif", fontSize:"clamp(22px,3.5vw,38px)", fontWeight:900, color:C.ink, lineHeight:1.2, marginBottom:40 }}>
            Follow 3 Simple Steps to Grow!
          </h2>
          <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
            {steps.map(s => (
              <div key={s.n} style={{ display:"flex", gap:18, alignItems:"start" }}>
                <div style={{ width:48, height:48, borderRadius:12, background:`linear-gradient(135deg,${C.green},${C.greenLight})`, display:"flex", alignItems:"center", justifyContent:"center", color:C.white, fontSize:14, fontWeight:900, flexShrink:0 }}>{s.n}</div>
                <div>
                  <h4 style={{ fontFamily:"'Merriweather',serif", fontSize:16, fontWeight:700, marginBottom:5 }}>{s.title}</h4>
                  <p style={{ fontSize:14, color:C.inkMid, lineHeight:1.75, fontWeight:500 }}>{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <button className="green-btn" onClick={() => setView("courses")} style={{ marginTop:36 }}>Get Started →</button>
        </div>

        <div className="stat-grid" style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18 }}>
          {[
            { n:"160+", l:"Courses", icon:"📚", color:`linear-gradient(135deg,${C.green},${C.greenLight})` },
            { n:"500+", l:"Students", icon:"🎓", color:`linear-gradient(135deg,${C.accent},#f7c55a)` },
            { n:"24K+", l:"Learners", icon:"🌍", color:`linear-gradient(135deg,#3b82f6,#60a5fa)` },
            { n:"12K+", l:"Reviews", icon:"⭐", color:`linear-gradient(135deg,#ec4899,#f472b6)` },
          ].map(s => (
            <div key={s.l} className="card" style={{ padding:24, textAlign:"center" }}>
              <div style={{ width:48, height:48, borderRadius:12, background:s.color, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, margin:"0 auto 12px" }}>{s.icon}</div>
              <div style={{ fontFamily:"'Merriweather',serif", fontSize:26, fontWeight:900, color:C.ink }}>{s.n}</div>
              <div style={{ fontSize:12, color:C.inkLight, fontWeight:600, marginTop:3 }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── COURSES SECTION ───────────────────────────────────────────
function CoursesSection({ courses, setView }) {
  return (
    <section style={{ background:`linear-gradient(135deg, ${C.greenDark} 0%, ${C.green} 100%)` }}>
      <div className="section-pad" style={{ maxWidth:1200, margin:"0 auto", padding:"80px 48px" }}>
        <div style={{ textAlign:"center", marginBottom:48 }}>
          <div className="section-label" style={{ justifyContent:"center", color:"rgba(255,255,255,0.8)" }}>Courses</div>
          <h2 style={{ fontFamily:"'Merriweather',serif", fontSize:"clamp(24px,4vw,40px)", fontWeight:900, color:C.white }}>
            Popular Courses For You
          </h2>
        </div>
        <div className="card-grid" style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))", gap:22, marginBottom:40 }}>
          {courses.map(c => (
            <div key={c.id} style={{ background:"rgba(255,255,255,0.08)", backdropFilter:"blur(10px)", border:"1px solid rgba(255,255,255,0.15)", borderRadius:20, padding:26, transition:"all 0.3s" }}
              onMouseEnter={e=>{e.currentTarget.style.background="rgba(255,255,255,0.14)";e.currentTarget.style.transform="translateY(-5px)";}}
              onMouseLeave={e=>{e.currentTarget.style.background="rgba(255,255,255,0.08)";e.currentTarget.style.transform="none";}}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:14 }}>
                <span style={{ background:"rgba(255,255,255,0.15)", color:C.white, padding:"4px 12px", borderRadius:50, fontSize:11, fontWeight:700, textTransform:"uppercase" }}>{c.level}</span>
                <span style={{ fontFamily:"'Merriweather',serif", fontSize:20, fontWeight:900, color:C.accent }}>{c.price}</span>
              </div>
              <h3 style={{ fontFamily:"'Merriweather',serif", fontSize:17, fontWeight:700, color:C.white, marginBottom:8, lineHeight:1.3 }}>{c.title}</h3>
              <p style={{ fontSize:13, color:"rgba(255,255,255,0.65)", lineHeight:1.75, marginBottom:18 }}>{c.description}</p>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontSize:13, color:"rgba(255,255,255,0.55)", fontWeight:600 }}>📚 {c.lessons} lessons</span>
                <button className="green-btn" style={{ padding:"8px 18px", fontSize:12 }}>Enrol</button>
              </div>
            </div>
          ))}
        </div>
        <div style={{ textAlign:"center" }}>
          <button className="outline-btn" onClick={() => setView("courses")}>View All Courses →</button>
        </div>
      </div>
    </section>
  );
}

// ── CARDS ─────────────────────────────────────────────────────
function PostCard({ post }) {
  const cats = { Design:{bg:"rgba(26,92,74,0.1)",c:C.green}, Coaching:{bg:"rgba(245,166,35,0.12)",c:C.accent}, Education:{bg:"rgba(59,130,246,0.1)",c:"#3b82f6"} };
  const s = cats[post.category] || {bg:C.offWhite, c:C.inkMid};
  return (
    <div className="card" style={{ padding:26 }}>
      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:14 }}>
        <span style={{ background:s.bg, color:s.c, padding:"4px 12px", borderRadius:50, fontSize:11, fontWeight:700, textTransform:"uppercase" }}>{post.category||"Blog"}</span>
        <span style={{ fontSize:12, color:C.inkLight, fontWeight:600 }}>{post.date}</span>
      </div>
      <h3 style={{ fontFamily:"'Merriweather',serif", fontSize:17, fontWeight:700, marginBottom:10, lineHeight:1.4 }}>{post.title}</h3>
      <p style={{ fontSize:14, color:C.inkMid, lineHeight:1.8, fontWeight:500 }}>{post.excerpt}</p>
      <button style={{ marginTop:16, background:"none", border:"none", color:C.green, fontWeight:700, cursor:"pointer", fontFamily:"'Nunito',sans-serif", fontSize:14 }}>Read More →</button>
    </div>
  );
}

function PortfolioCard({ item }) {
  return (
    <div className="card" style={{ padding:26 }}>
      <div style={{ width:"100%", height:130, borderRadius:12, background:`linear-gradient(135deg,rgba(26,92,74,0.1),rgba(245,166,35,0.1))`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:36, marginBottom:18 }}>🎨</div>
      <h3 style={{ fontFamily:"'Merriweather',serif", fontSize:17, fontWeight:700, marginBottom:8 }}>{item.title}</h3>
      <p style={{ fontSize:14, color:C.inkMid, lineHeight:1.8, fontWeight:500, marginBottom:12 }}>{item.description}</p>
      <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:14 }}>
        {(item.tags||"").split(",").map(t => <span key={t} style={{ background:C.offWhite, color:C.inkMid, padding:"4px 10px", borderRadius:50, fontSize:11, fontWeight:700 }}>{t.trim()}</span>)}
      </div>
      {item.link && item.link!=="#" && <a href={item.link} style={{ fontSize:13, color:C.green, fontWeight:700, textDecoration:"none" }}>View project →</a>}
    </div>
  );
}

function PdfCard({ pdf }) {
  return (
    <div className="card" style={{ padding:22, display:"flex", gap:16, alignItems:"center" }}>
      <div style={{ width:52, height:52, borderRadius:12, background:`linear-gradient(135deg,${C.green},${C.greenLight})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22, flexShrink:0 }}>📄</div>
      <div style={{ flex:1 }}>
        <h4 style={{ fontFamily:"'Merriweather',serif", fontSize:15, fontWeight:700, marginBottom:3 }}>{pdf.title}</h4>
        <p style={{ fontSize:13, color:C.inkMid, fontWeight:500 }}>{pdf.description}</p>
        {pdf.size && <span style={{ fontSize:12, color:C.inkLight }}>{pdf.size}</span>}
      </div>
      <a href={pdf.file_url} target="_blank" rel="noreferrer"><button className="ghost-btn" style={{ fontSize:12, padding:"8px 16px" }}>Download</button></a>
    </div>
  );
}

// ── CTA + FOOTER ──────────────────────────────────────────────
function CTAStrip({ setView }) {
  return (
    <section style={{ background:C.accent }}>
      <div className="section-pad" style={{ maxWidth:700, margin:"0 auto", padding:"72px 24px", textAlign:"center" }}>
        <h2 style={{ fontFamily:"'Merriweather',serif", fontSize:"clamp(24px,4vw,42px)", fontWeight:900, color:C.ink, marginBottom:16 }}>Ready to Start Your Journey?</h2>
        <p style={{ fontSize:16, color:"rgba(0,0,0,0.6)", lineHeight:1.8, marginBottom:32, fontWeight:500 }}>Whether it's design, coaching, or education — take the first step today.</p>
        <div style={{ display:"flex", gap:14, justifyContent:"center", flexWrap:"wrap" }}>
          <button className="teal-btn" onClick={() => setView("courses")} style={{ fontSize:15, padding:"14px 32px" }}>Explore Courses</button>
          <button onClick={() => setView("portfolio")} style={{ background:C.ink, color:C.white, padding:"14px 32px", borderRadius:50, border:"none", fontFamily:"'Nunito',sans-serif", fontSize:15, fontWeight:800, cursor:"pointer" }}>View My Work</button>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer style={{ background:C.greenDark, padding:"48px 24px 28px" }}>
      <div className="footer-flex" style={{ maxWidth:1200, margin:"0 auto", display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:20, marginBottom:28 }}>
        <div>
          <div style={{ fontFamily:"'Merriweather',serif", fontSize:22, fontWeight:900, color:C.white, marginBottom:4 }}>Prosper<span style={{ color:C.accent }}>.</span></div>
          <p style={{ fontSize:13, color:"rgba(255,255,255,0.45)", fontWeight:500 }}>Web Designer · Coach · Educator</p>
        </div>
        <div className="footer-socials" style={{ display:"flex", gap:10 }}>
          {["LinkedIn","Twitter","Instagram","GitHub"].map(s => (
            <button key={s} style={{ background:"rgba(255,255,255,0.08)", color:"rgba(255,255,255,0.6)", border:"1px solid rgba(255,255,255,0.1)", padding:"8px 14px", borderRadius:50, fontFamily:"'Nunito',sans-serif", fontSize:12, fontWeight:700, cursor:"pointer" }}>{s}</button>
          ))}
        </div>
      </div>
      <div style={{ borderTop:"1px solid rgba(255,255,255,0.08)", paddingTop:20, textAlign:"center" }}>
        <p style={{ fontSize:12, color:"rgba(255,255,255,0.3)", fontWeight:500 }}>© 2026 Prosper. All rights reserved.</p>
      </div>
    </footer>
  );
}

// ── PAGE WRAPPER ──────────────────────────────────────────────
function PageWrap({ label, title, subtitle, dark, children }) {
  return (
    <div>
      <div style={{ background: dark?`linear-gradient(135deg,${C.greenDark},${C.green})`:`linear-gradient(135deg,${C.offWhite},${C.white})`, padding:"110px 48px 56px", borderBottom:`1px solid ${C.border}` }}>
        <div className="page-pad" style={{ maxWidth:1200, margin:"0 auto", padding:"0" }}>
          <div className="section-label" style={{ color:dark?C.accent:C.green }}>{label}</div>
          <h1 style={{ fontFamily:"'Merriweather',serif", fontSize:"clamp(26px,4vw,48px)", fontWeight:900, color:dark?C.white:C.ink, lineHeight:1.15, marginTop:4 }}>{title}</h1>
          {subtitle && <p style={{ fontSize:15, color:dark?"rgba(255,255,255,0.65)":C.inkMid, marginTop:10, fontWeight:500 }}>{subtitle}</p>}
        </div>
      </div>
      <div className="section-pad" style={{ maxWidth:1200, margin:"0 auto", padding:"52px 48px 80px" }}>{children}</div>
    </div>
  );
}

// ── ADMIN ─────────────────────────────────────────────────────
function AdminPanel({ posts,courses,portfolios,pdfs,setPosts,setCourses,setPortfolios,setPdfs }) {
  const [tab,setTab]=useState("posts");
  const [modal,setModal]=useState(false);
  const [form,setForm]=useState({});
  const [saving,setSaving]=useState(false);
  const [msg,setMsg]=useState("");
  const tabs=[{id:"posts",l:"Posts",icon:"✍️"},{id:"courses",l:"Courses",icon:"🎓"},{id:"portfolios",l:"Portfolio",icon:"🎨"},{id:"pdfs",l:"PDFs",icon:"📄"}];
  const data={posts,courses,portfolios,pdfs}[tab];
  const notify=m=>{setMsg(m);setTimeout(()=>setMsg(""),3000);};
  const u=(k,v)=>setForm(f=>({...f,[k]:v}));
  const setters={posts:setPosts,courses:setCourses,portfolios:setPortfolios,pdfs:setPdfs};

  const handleSave=async()=>{
    if(!form.title)return notify("Title is required");
    setSaving(true);
    const item={...form,id:Date.now(),date:new Date().toISOString().split("T")[0]};
    if(!isDemo){try{await sb.insert(tab,item);}catch(e){notify("Supabase error");}}
    setters[tab](p=>[item,...p]);
    setSaving(false);setModal(false);notify("✅ Added!");
  };
  const handleDelete=async id=>{
    if(!window.confirm("Delete?"))return;
    if(!isDemo)await sb.del(tab,id);
    setters[tab](p=>p.filter(x=>x.id!==id));
    notify("🗑 Deleted");
  };

  const F=()=>{
    if(tab==="posts")return(<><label>Title</label><input value={form.title||""} onChange={e=>u("title",e.target.value)} placeholder="Post title"/><label>Category</label><input value={form.category||""} onChange={e=>u("category",e.target.value)} placeholder="Design, Coaching..."/><label>Excerpt</label><textarea rows={3} value={form.excerpt||""} onChange={e=>u("excerpt",e.target.value)}/><label>Image URL</label><input value={form.image||""} onChange={e=>u("image",e.target.value)} placeholder="https://..."/></>);
    if(tab==="courses")return(<><label>Title</label><input value={form.title||""} onChange={e=>u("title",e.target.value)}/><label>Description</label><textarea rows={3} value={form.description||""} onChange={e=>u("description",e.target.value)}/><label>Price</label><input value={form.price||""} onChange={e=>u("price",e.target.value)} placeholder="Free / $49"/><label>Level</label><select value={form.level||""} onChange={e=>u("level",e.target.value)}><option value="">Select</option><option>Beginner</option><option>Intermediate</option><option>Advanced</option><option>All Levels</option></select><label>Lessons</label><input type="number" value={form.lessons||""} onChange={e=>u("lessons",e.target.value)}/></>);
    if(tab==="portfolios")return(<><label>Title</label><input value={form.title||""} onChange={e=>u("title",e.target.value)}/><label>Description</label><textarea rows={3} value={form.description||""} onChange={e=>u("description",e.target.value)}/><label>Tags</label><input value={form.tags||""} onChange={e=>u("tags",e.target.value)} placeholder="Design, React..."/><label>Live Link</label><input value={form.link||""} onChange={e=>u("link",e.target.value)}/><label>Image URL</label><input value={form.image||""} onChange={e=>u("image",e.target.value)}/></>);
    if(tab==="pdfs")return(<><label>Title</label><input value={form.title||""} onChange={e=>u("title",e.target.value)}/><label>Description</label><textarea rows={2} value={form.description||""} onChange={e=>u("description",e.target.value)}/><label>File URL</label><input value={form.file_url||""} onChange={e=>u("file_url",e.target.value)}/><label>Size</label><input value={form.size||""} onChange={e=>u("size",e.target.value)} placeholder="2.4 MB"/></>);
  };

  return(
    <div className="admin-pad" style={{maxWidth:1000,margin:"0 auto",padding:"110px 48px 80px"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:32,flexWrap:"wrap",gap:12}}>
        <div>
          <h1 style={{fontFamily:"'Merriweather',serif",fontSize:"clamp(22px,4vw,30px)",fontWeight:900,color:C.ink}}>Admin Dashboard</h1>
          <p style={{color:C.inkLight,fontSize:14,marginTop:4}}>{isDemo?"🟡 Demo mode — connect Supabase to persist":"🟢 Connected to Supabase"}</p>
        </div>
        {msg&&<div style={{background:"rgba(26,92,74,0.1)",color:C.green,border:`1px solid rgba(26,92,74,0.2)`,padding:"10px 18px",borderRadius:12,fontSize:14,fontWeight:700}}>{msg}</div>}
      </div>
      {isDemo&&<div className="card" style={{padding:18,background:"rgba(245,166,35,0.05)",borderColor:"rgba(245,166,35,0.3)",marginBottom:22}}><p style={{fontSize:13,color:C.inkMid,lineHeight:1.8}}><strong style={{color:C.accent}}>Connect Supabase:</strong> Replace YOUR_SUPABASE_URL and YOUR_SUPABASE_ANON_KEY at the top of this file with your credentials from supabase.com → Settings → API.</p></div>}

      <div style={{display:"flex",gap:8,marginBottom:20,flexWrap:"wrap"}}>
        {tabs.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{padding:"9px 18px",borderRadius:50,border:`2px solid ${tab===t.id?C.green:C.border}`,background:tab===t.id?`rgba(26,92,74,0.08)`:C.white,color:tab===t.id?C.green:C.inkMid,cursor:"pointer",fontFamily:"'Nunito',sans-serif",fontSize:13,fontWeight:tab===t.id?800:600,transition:"all 0.2s"}}>
            {t.icon} {t.l} ({data.length})
          </button>
        ))}
        <button className="teal-btn" onClick={()=>{setForm({});setModal(true);}} style={{marginLeft:"auto",padding:"9px 20px",fontSize:13}}>+ Add New</button>
      </div>

      <div className="card" style={{padding:0,overflow:"hidden"}}>
        {data.length===0
          ?<div style={{textAlign:"center",padding:"52px 20px",color:C.inkLight}}><div style={{fontSize:36,marginBottom:10}}>{tabs.find(t=>t.id===tab)?.icon}</div><p>No {tab} yet. Click "+ Add New".</p></div>
          :<table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead><tr style={{borderBottom:`1px solid ${C.border}`,background:C.offWhite}}>
              {["Title","Details","Actions"].map(h=><th key={h} style={{padding:"13px 20px",textAlign:h==="Actions"?"right":"left",fontSize:11,color:C.inkLight,fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase"}}>{h}</th>)}
            </tr></thead>
            <tbody>{data.map((item,i)=>(
              <tr key={item.id} style={{borderBottom:i<data.length-1?`1px solid ${C.border}`:"none",transition:"background 0.15s"}}
                onMouseEnter={e=>e.currentTarget.style.background=C.offWhite}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <td style={{padding:"14px 20px"}}><div style={{fontWeight:700,fontSize:14,color:C.ink}}>{item.title}</div>{item.date&&<div style={{fontSize:11,color:C.inkLight,marginTop:2}}>{item.date}</div>}</td>
                <td className="admin-table-details" style={{padding:"14px 20px"}}>
                  {tab==="posts"&&<span style={{background:"rgba(26,92,74,0.1)",color:C.green,padding:"3px 10px",borderRadius:50,fontSize:11,fontWeight:700}}>{item.category||"Blog"}</span>}
                  {tab==="courses"&&<div style={{display:"flex",gap:6}}><span style={{background:"rgba(26,92,74,0.1)",color:C.green,padding:"3px 10px",borderRadius:50,fontSize:11,fontWeight:700}}>{item.level}</span><span style={{background:"rgba(245,166,35,0.12)",color:C.accent,padding:"3px 10px",borderRadius:50,fontSize:11,fontWeight:700}}>{item.price}</span></div>}
                  {tab==="portfolios"&&<div style={{display:"flex",gap:5,flexWrap:"wrap"}}>{(item.tags||"").split(",").slice(0,2).map(t=><span key={t} style={{background:C.offWhite,color:C.inkMid,padding:"3px 8px",borderRadius:50,fontSize:11,fontWeight:700}}>{t.trim()}</span>)}</div>}
                  {tab==="pdfs"&&<span style={{fontSize:12,color:C.inkLight,fontWeight:600}}>{item.size||"—"}</span>}
                </td>
                <td style={{padding:"14px 20px",textAlign:"right"}}><button className="danger-btn" onClick={()=>handleDelete(item.id)}>Delete</button></td>
              </tr>
            ))}</tbody>
          </table>}
      </div>

      {modal&&(
        <div style={{position:"fixed",inset:0,background:"rgba(15,61,49,0.75)",backdropFilter:"blur(8px)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
          <div className="card" style={{width:"100%",maxWidth:520,maxHeight:"90vh",overflowY:"auto",padding:32,animation:"fadeUp 0.3s ease both"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
              <h3 style={{fontFamily:"'Merriweather',serif",fontSize:20,fontWeight:700}}>Add New {tab.slice(0,-1)}</h3>
              <button onClick={()=>setModal(false)} style={{background:"none",border:"none",color:C.inkLight,cursor:"pointer",fontSize:22}}>✕</button>
            </div>
            <F/>
            <div style={{display:"flex",gap:12,marginTop:22}}>
              <button className="teal-btn" onClick={handleSave} disabled={saving} style={{padding:"11px 24px",fontSize:13}}>{saving?"Saving...":"Save"}</button>
              <button className="ghost-btn" onClick={()=>setModal(false)} style={{padding:"11px 20px",fontSize:13}}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── ROOT ──────────────────────────────────────────────────────
export default function App() {
  const [view,setView]=useState("home");
  const [isAdmin,setIsAdmin]=useState(false);
  const [loginModal,setLoginModal]=useState(false);
  const [pw,setPw]=useState("");
  const [pwErr,setPwErr]=useState("");
  const [posts,setPosts]=useState(DEMO.posts);
  const [courses,setCourses]=useState(DEMO.courses);
  const [portfolios,setPortfolios]=useState(DEMO.portfolios);
  const [pdfs,setPdfs]=useState(DEMO.pdfs);

  useEffect(()=>{
    if(!isDemo){
      sb.query("posts",{order:"date.desc"}).then(d=>Array.isArray(d)&&setPosts(d));
      sb.query("courses").then(d=>Array.isArray(d)&&setCourses(d));
      sb.query("portfolios").then(d=>Array.isArray(d)&&setPortfolios(d));
      sb.query("pdfs").then(d=>Array.isArray(d)&&setPdfs(d));
    }
  },[]);

  const handleLogin=()=>{
    if(pw===ADMIN_PASSWORD){setIsAdmin(true);setLoginModal(false);setPw("");setPwErr("");setView("admin");}
    else setPwErr("Incorrect password");
  };

  return(
    <>
      <style>{css}</style>
      <Nav view={view} setView={setView} isAdmin={isAdmin}
        onAdminClick={()=>setLoginModal(true)}
        onLogout={()=>{setIsAdmin(false);setView("home");}}/>

      {view==="home"&&<>
        <Hero setView={setView}/>
        <WhyChoose/>
        <HowItWorks setView={setView}/>
        <CoursesSection courses={courses} setView={setView}/>
        <CTAStrip setView={setView}/>
        <Footer/>
      </>}

      {view==="posts"&&<><PageWrap label="Writing" title="Blog & Articles" subtitle="Thoughts on design, coaching, and education.">
        <div className="card-grid" style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:22}}>
          {posts.map(p=><PostCard key={p.id} post={p}/>)}
        </div>
      </PageWrap><Footer/></>}

      {view==="courses"&&<><PageWrap label="Learning" title="Courses & Programmes" subtitle="Build skills. Transform your life." dark>
        <div className="card-grid" style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:22}}>
          {courses.map(c=>(
            <div key={c.id} className="card" style={{padding:26}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:14}}>
                <span style={{background:"rgba(26,92,74,0.1)",color:C.green,padding:"4px 12px",borderRadius:50,fontSize:11,fontWeight:700,textTransform:"uppercase"}}>{c.level}</span>
                <span style={{fontFamily:"'Merriweather',serif",fontSize:20,fontWeight:900,color:C.accent}}>{c.price}</span>
              </div>
              <h3 style={{fontFamily:"'Merriweather',serif",fontSize:17,fontWeight:700,marginBottom:8}}>{c.title}</h3>
              <p style={{fontSize:14,color:C.inkMid,lineHeight:1.8,fontWeight:500,marginBottom:16}}>{c.description}</p>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{fontSize:13,color:C.inkLight,fontWeight:600}}>📚 {c.lessons} lessons</span>
                <button className="teal-btn" style={{padding:"8px 18px",fontSize:12}}>Enrol</button>
              </div>
            </div>
          ))}
        </div>
      </PageWrap><Footer/></>}

      {view==="portfolio"&&<><PageWrap label="Portfolio" title="Selected Work" subtitle="Projects I'm proud of.">
        <div className="card-grid" style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:22}}>
          {portfolios.map(p=><PortfolioCard key={p.id} item={p}/>)}
        </div>
      </PageWrap><Footer/></>}

      {view==="resources"&&<><PageWrap label="Downloads" title="Free Resources" subtitle="PDFs and guides — yours to keep.">
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          {pdfs.map(p=><PdfCard key={p.id} pdf={p}/>)}
        </div>
      </PageWrap><Footer/></>}

      {view==="admin"&&isAdmin&&<><AdminPanel posts={posts} courses={courses} portfolios={portfolios} pdfs={pdfs}
        setPosts={setPosts} setCourses={setCourses} setPortfolios={setPortfolios} setPdfs={setPdfs}/><Footer/></>}

      {loginModal&&(
        <div style={{position:"fixed",inset:0,background:"rgba(15,61,49,0.75)",backdropFilter:"blur(10px)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
          <div className="card" style={{width:"100%",maxWidth:400,padding:36,animation:"fadeUp 0.3s ease both"}}>
            <h3 style={{fontFamily:"'Merriweather',serif",fontSize:22,fontWeight:900,marginBottom:8}}>Admin Login</h3>
            <p style={{fontSize:14,color:C.inkMid,marginBottom:22,fontWeight:500}}>Enter your password to access the dashboard.</p>
            <label>Password</label>
            <input type="password" value={pw} onChange={e=>setPw(e.target.value)} placeholder="Enter password"
              onKeyDown={e=>e.key==="Enter"&&handleLogin()} autoFocus/>
            {pwErr&&<p style={{color:"#dc3545",fontSize:13,marginTop:8,fontWeight:600}}>{pwErr}</p>}
            <div style={{display:"flex",gap:12,marginTop:22}}>
              <button className="teal-btn" onClick={handleLogin} style={{padding:"11px 24px",fontSize:13}}>Login</button>
              <button className="ghost-btn" onClick={()=>{setLoginModal(false);setPw("");setPwErr("");}} style={{padding:"11px 18px",fontSize:13}}>Cancel</button>
            </div>
            <p style={{fontSize:12,color:C.inkLight,marginTop:14,fontWeight:500}}>Default: admin123 — change before going live.</p>
          </div>
        </div>
      )}
    </>
  );
}
